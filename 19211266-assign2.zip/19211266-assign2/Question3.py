import pandas as pd
import networkx as nx
import numpy as np

articles = pd.read_csv("article-ids.csv")
category_id_map = pd.read_csv("category-ids.csv")
category_id_map.set_index("Category_Name", inplace= True)
category_id_map = category_id_map.to_dict()['Category_ID']
d= {}
with open("wikispeedia_paths-and-graph/categories.tsv") as f:
  for line in f:
    if "subject." in line:
      s1, s2 = line.strip().split()
      d.setdefault(s1, set())
      d[s1] = d[s1].union([category_id_map[s2]])
articles['Category_ID'] = articles.Article_Name.map(d)
def article_cat(col):
  if isinstance(col, set):
    return ",".join(sorted(list(col)))
articles['Category_ID'] = articles['Category_ID'].apply(article_cat)
articles['Category_ID'] = articles['Category_ID'].replace(np.nan, 'C0001')
articles[['Article_ID', 'Category_ID']].to_csv("article-categories.csv", index= False)