import pandas as pd
import networkx as nx
import numpy as np

finished_wbc = pd.read_csv("finished-paths-no-back.csv")
finished_bc = pd.read_csv("finished-paths-back.csv")
finished_wbc = finished_wbc.astype(float)
finished_bc = finished_bc.astype(float)
equal_1 = [len(finished_wbc[finished_wbc.Ratio==1])/len(finished_wbc)*100]
for i in range(1,11):
  equal_1.append(len(finished_wbc[finished_wbc.Human_Path_Length-finished_wbc.Shortest_Path_Length == i])/len(finished_wbc)*100)
equal_1.append(len(finished_wbc[finished_wbc.Human_Path_Length-finished_wbc.Shortest_Path_Length >=11])/len(finished_wbc)*100)

with open("percentage-paths-no-back.csv", 'w') as f:
  f.write("Equal_Length,Larger_by_1,Larger_by_2,Larger_by_3,Larger_by_4,Larger_by_5,Larger_by_6,Larger_by_7,Larger_by_8,Larger_by_9,Larger_by_10,Larger_by_more_than_10\n")
  f.write(",".join(map(str, equal_1)))

equal_2 = [len(finished_bc[finished_bc.Ratio==1])/len(finished_bc)*100]
for i in range(1,11):
  equal_2.append(len(finished_bc[finished_bc.Human_Path_Length-finished_bc.Shortest_Path_Length == i])/len(finished_bc)*100)
equal_2.append(len(finished_bc[finished_bc.Human_Path_Length-finished_bc.Shortest_Path_Length >=11])/len(finished_bc)*100)

with open("percentage-paths-back.csv", 'w') as f:
  f.write("Equal_Length,Larger_by_1,Larger_by_2,Larger_by_3,Larger_by_4,Larger_by_5,Larger_by_6,Larger_by_7,Larger_by_8,Larger_by_9,Larger_by_10,Larger_by_more_than_10\n")
  f.write(",".join(map(str, equal_2)))