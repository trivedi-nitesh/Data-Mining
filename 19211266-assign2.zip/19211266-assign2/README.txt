###### FOLDER CONTENTS #########

1) Folder contains eleven python files named as Question1, Question2, ... Question11.
2) Folder contains eleven bash files named as Question1.sh, Question2.sh, ... Question11.sh.
3) A top level bash file assign2.sh
4) Folder named wikispeedia_paths-and-graph containing input files.
5) report.tex file(along with llncs.cls and Charts folder having plots)
6) report.pdf file
7) README.txt

################# REQUIREMENTS #############################

Below is the list of packages(along with their versions) used in code.

################################################################################
Packages	  Versions

networkx           2.5
pandas             1.1.4
numpy              1.18.5


Note- All pyhton scripts have been written on google colab.
#################################################################################

########## HOW TO EXECUTE CODE ##################################################

In order to execute complete assignment as a whole, please execute "assign2.sh". This will generate outputs
of all questions at a time.


###### Order(top to bottom) to be followed while exectuing shell files independently ###################

1) Question1.sh
2) Question2.sh
3) Question3.sh
4) Question4.sh
5) Question5.sh
6) Question6.sh
7) Question7.sh
8) Question8.sh
9) Question9.sh
10) Question10.sh
11) Question11.sh
