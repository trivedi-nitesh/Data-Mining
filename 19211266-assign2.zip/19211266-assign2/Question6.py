import pandas as pd
import networkx as nx
import numpy as np

articles = pd.read_csv("article-ids.csv")
articles.set_index("Article_Name", inplace= True)
article_id_map = articles.to_dict()['Article_ID']
final = []
with open('wikispeedia_paths-and-graph/shortest-path-distance-matrix.txt') as f:
  for line in f:
    line = line.strip()
    if len(line)!=0 and line[0] in "0123456789_":
      a = [int(i) if i!= '_' else float('inf') for i in line]
      final.append(a)
arr = np.asarray(final)
finished_paths = []
with open('wikispeedia_paths-and-graph/paths_finished.tsv') as f:
  for line in f:
    if line[0] in '0123456789N':
      line = line.strip().split()[3]
      finished_paths.append(line)

############ Without Back Clicks#########################
def path_wbc(a1, map_dict, arr):
  l1 = []
  a1 = a1.split(";")
  for i in a1:
    l1.append(i) if i != '<' else l1.pop()
  n = len(l1)
  human_len, source, desti =  n, l1[0], l1[n-1]
  human_len = human_len-1
  source, desti = map_dict[source], map_dict[desti]
  source, desti = int(source[1:]), int(desti[1:])
  shortest_len = arr[source-1, desti-1]
  if shortest_len != 0:
    ratio = human_len/shortest_len
  else:
    ratio = float('inf')
  return human_len, shortest_len, ratio
  
dummy_list = []
for ele in finished_paths:
  dummy_list.append((path_wbc(ele, article_id_map, arr)))
with open('finished-paths-no-back.csv', 'w') as f:
  f.write(f"Human_Path_Length,Shortest_Path_Length,Ratio\n")
  for ele in dummy_list:
    f.write(f"{ele[0]}, {ele[1]}, {ele[2]} \n")

######################### With Back-Clicks############################
def path_bc(a1, map_dict, arr):
  j = 0
  a1 = a1.split(";")
  for i in range(len(a1)):
    if a1[i] == '<':
      j = j+2
      a1[i] = a1[i-j]
    else:
      j = j+2
  n = len(a1)
  human_len, source, desti =  n, a1[0], a1[n-1]
  human_len = human_len-1
  source, desti = map_dict[source], map_dict[desti]
  source, desti = int(source[1:]), int(desti[1:])
  shortest_len = arr[source-1, desti-1]
  if shortest_len != 0:
    ratio = human_len/shortest_len
  else:
    ratio = float('inf')
  return human_len, shortest_len, ratio

dummy_list = []
for ele in finished_paths:
  dummy_list.append((path_bc(ele, article_id_map, arr)))
with open('finished-paths-back.csv', 'w') as f:
  f.write(f"Human_Path_Length,Shortest_Path_Length,Ratio\n")
  for ele in dummy_list:
    f.write(f"{ele[0]}, {ele[1]}, {ele[2]} \n")