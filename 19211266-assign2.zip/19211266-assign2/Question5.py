import pandas as pd
import networkx as nx
import numpy as np

edges_df = pd.read_csv("edges.csv")
G = nx.from_pandas_edgelist(edges_df, source='From_ArticleID', target='To_ArticleID',create_using=nx.DiGraph())
nodes_id = set(G.nodes())
articles = pd.read_csv("article-ids.csv")
article_dict = articles.set_index("Article_Name")
article_dict = article_dict.to_dict()["Article_ID"]
arti_id = {v for k,v in article_dict.items()}
for i in arti_id.difference(nodes_id):
  G.add_node(i)

with open("graph-components.csv", 'w') as out:
  out.write(f"Nodes, Edges, Diameter\n")
  for i in sorted(list(nx.strongly_connected_components(G)), key= len):
    H = G.subgraph(list(i))
    out.write(f"{len(H.nodes())}, {len(H.edges())}, {nx.diameter(H)}\n")