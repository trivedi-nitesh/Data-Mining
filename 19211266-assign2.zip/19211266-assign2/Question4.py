import pandas as pd
import networkx as nx
import numpy as np

final = []
with open('wikispeedia_paths-and-graph/shortest-path-distance-matrix.txt') as f:
  for line in f:
    line = line.strip()
    if len(line)!=0 and line[0] in "0123456789_":
      a = [1 if i =='1' else 0 for i in line]
      final.append(a)
arr = np.asarray(final)
nodes_tup =[]
for i in range(4604):
  for j in range(4604):
    if arr[i,j] == 1:
      nodes_tup.append((i,j))
edge_df = pd.DataFrame(nodes_tup, columns= ["from", "to"])
nodes_id = {article:'A'+str(f"{idx:04}") for idx, article in enumerate(range(4604),1)}
edge_df['From_ArticleID'] = edge_df['from'].map(nodes_id)
edge_df['To_ArticleID'] = edge_df['to'].map(nodes_id)
edge_df[['From_ArticleID', 'To_ArticleID']].to_csv('edges.csv', index = False)