import pandas as pd
import networkx as nx
import numpy as np

data = set()
with open("wikispeedia_paths-and-graph/categories.tsv") as f:
  for line in f:
    if "subject." in line:
      line = line.strip().split()[1]
      data.add(line)
data = [ele.split(".") for ele in data]
data_subsets= []
for elements in data:
  data_dummy = []
  for i in range(0,len(elements)):
    data_dummy.append(".".join(elements[:i+1]))
  data_subsets.append(data_dummy)
complete_trie = {}
for element in data_subsets:
  node = complete_trie
  for ele in element:
    node.setdefault(ele, {})
    node = node[ele]
def all_tries(full_trie, tries, curr_tries):
    #print(sorted(full_trie.keys()))
    for k in sorted(full_trie.keys()):
        curr_tries.append(full_trie[k])
    tries.extend(curr_tries)    
    for trie in curr_tries :
        all_tries(trie, tries, [])
    ans = []
    for trie in tries:
        ans.extend(sorted(trie.keys()))
    return ans

a = all_tries(complete_trie, [complete_trie], [])
category_ids= ['C'+str(f"{i:04}") for i in range(1,len(a)+1)]
category_id_map= [(i, j) for i,j in zip(a, category_ids)]
with open('category-ids.csv','w') as out:
  out.write(f"Category_Name,Category_ID\n")
  for k,v in category_id_map:
    out.write(f"{k},{v}\n")