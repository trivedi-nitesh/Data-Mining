import pandas as pd
import networkx as nx
import numpy as np
articles = pd.read_csv("wikispeedia_paths-and-graph/articles.tsv", skiprows=range(12), header= None)
articles.columns = ['Article_Name']
article_names = articles.Article_Name.to_list()
article_ids= ['A'+str(f"{i:04}") for i in range(1,4665)]
articles_id_map= {i: j for i,j in zip(article_names,article_ids)}
articles['Article_ID'] = articles['Article_Name'].map(articles_id_map)
articles.to_csv("article-ids.csv", index= False)