import pandas as pd
import networkx as nx
import numpy as np


d= {}
with open("wikispeedia_paths-and-graph/categories.tsv") as f:
  for line in f:
    if "subject." in line:
      s1, s2 = line.strip().split()
      d.setdefault(s1, set())
      d[s1] = d[s1].union([s2])
d['Directdebit'] = {'subject'}
d['Donation'] = {'subject'}
d['Friend_Directdebit'] = {'subject'}
d['Pikachu'] = {'subject'}
d['Sponsorship_Directdebit'] = {'subject'}
d['Wowpurchase'] = {'subject'}

finished_paths = []
with open('wikispeedia_paths-and-graph/paths_finished.tsv') as f:
  for line in f:
    if line[0] in '0123456789N':
      line = line.strip().split()[3]
      finished_paths.append(line)
	  
del finished_paths[2395]
del finished_paths[5857]
del finished_paths[9589]
del finished_paths[9872]
del finished_paths[20919]
del finished_paths[23347]
del finished_paths[24326]
del finished_paths[30761]
del finished_paths[33832]
del finished_paths[34302]
del finished_paths[38927]
del finished_paths[50466]

category_id_map = pd.read_csv("category-ids.csv")
category_dict = category_id_map.set_index("Category_Name")
category_dict = category_dict.to_dict()['Category_ID']

######################### Human Path#################################

human_count = {k:0 for k in category_dict.keys()}
human_times = {k:0 for k in category_dict.keys()}

def without_bc(a1):
  l1 = []
  a1 = a1.split(";")
  for i in a1:
    l1.append(i) if i != '<' else l1.pop()
  return l1

for ele in finished_paths:
  path = without_bc(ele)
  cat = []
  for arti in path:
    cat.append(d[arti])
  cat = set.union(*cat)
  for entry in cat:
    human_count[entry]+=1

category_id_map["Number_of_human_paths_traversed"] = category_id_map.Category_Name.map(human_count)

for ele in finished_paths:
  path = without_bc(ele)
  cat =[]
  for arti in path:
    cat += d[arti]
  for entry in cat:
    human_times[entry]+=1
	
category_id_map["Number_of_human_times_traversed"] = category_id_map.Category_Name.map(human_times)

######################### Shortest Path####################################

articles = pd.read_csv("article-ids.csv")
article_dict = articles.set_index("Article_Name")
article_dict = article_dict.to_dict()["Article_ID"]
article_dict_inv = {v:k for k,v in article_dict.items()}
human_count = {k:0 for k in category_dict.keys()}
human_times = {k:0 for k in category_dict.keys()}

edges_df = pd.read_csv("edges.csv")
G = nx.from_pandas_edgelist(edges_df, source='From_ArticleID', target='To_ArticleID',create_using=nx.DiGraph())
nodes_id = set(G.nodes())
arti_id = {v for k,v in article_dict.items()}
for i in arti_id.difference(nodes_id):
  G.add_node(i)

def without_bc_short(a1):
  l1 = []
  a1 = a1.split(";")
  for i in a1:
    l1.append(i) if i != '<' else l1.pop()
  return l1[0], l1[-1]

for ele in finished_paths:
  source, desti = without_bc_short(ele)
  source, desti = article_dict[source], article_dict[desti]
  if source != 'A0591' and desti != 'A4481':
    path = nx.shortest_path(G, source=source, target=desti, weight=None)
    path = [article_dict_inv[i] for i in path]
    cat = []
    for arti in path:
      cat.append(d[arti])
    cat = set.union(*cat)
    for entry in cat:
      human_count[entry]+=1

category_id_map["Number_of_shortest_paths_traversed"] = category_id_map.Category_Name.map(human_count)

for ele in finished_paths:
  source, desti = without_bc_short(ele)
  source, desti = article_dict[source], article_dict[desti]
  if source != 'A0591' and desti != 'A4481':
    path = nx.shortest_path(G, source=source, target=desti, weight=None)
    path = [article_dict_inv[i] for i in path]
    cat = []
    for arti in path:
      cat+= d[arti]
    for entry in cat:
      human_times[entry]+=1

category_id_map["Number_of_shortest_times_traversed"] = category_id_map.Category_Name.map(human_times)

category_id_map[['Category_ID','Number_of_human_paths_traversed','Number_of_human_times_traversed','Number_of_shortest_paths_traversed','Number_of_shortest_times_traversed']].to_csv("category-paths.csv", index= False)