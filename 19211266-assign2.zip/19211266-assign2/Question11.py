import pandas as pd
import networkx as nx
import numpy as np

final = []
with open('wikispeedia_paths-and-graph/shortest-path-distance-matrix.txt') as f:
  for line in f:
    line = line.strip()
    if len(line)!=0 and line[0] in "0123456789_":
      a = [int(i) if i!= '_' else float('inf') for i in line]
      final.append(a)
arr = np.asarray(final)

finished_paths = []
with open('wikispeedia_paths-and-graph/paths_finished.tsv') as f:
  for line in f:
    if line[0] in '0123456789N':
      line = line.strip().split()[3]
      finished_paths.append(line)
	  
del finished_paths[2395]
del finished_paths[5857]
del finished_paths[9589]
del finished_paths[9872]
del finished_paths[20919]
del finished_paths[23347]
del finished_paths[24326]
del finished_paths[30761]
del finished_paths[33832]
del finished_paths[34302]
del finished_paths[38927]
del finished_paths[50466]


d= {}
with open("wikispeedia_paths-and-graph/categories.tsv") as f:
  for line in f:
    if "subject." in line:
      s1, s2 = line.strip().split()
      s2 = s2.split('.')
      for i in range(len(s2)):
        d.setdefault(s1, set())
        d[s1] = d[s1].union([".".join(s2[:i+1])])
d['Directdebit'] = {'subject'}
d['Donation'] = {'subject'}
d['Friend_Directdebit'] = {'subject'}
d['Pikachu'] = {'subject'}
d['Sponsorship_Directdebit'] = {'subject'}
d['Wowpurchase'] = {'subject'}

category_id_map = pd.read_csv("category-ids.csv")
category_dict = category_id_map.set_index("Category_Name")
category_dict = category_dict.to_dict()['Category_ID']
	  
def without_bc(a1):
  l1 = []
  a1 = a1.split(";")
  for i in a1:
    l1.append(i) if i != '<' else l1.pop()
  return l1
  
articles = pd.read_csv("article-ids.csv")
article_dict = articles.set_index("Article_Name")
article_dict = article_dict.to_dict()["Article_ID"]

ratio_sum = {}
ratio_count = {}
for ele in finished_paths:
  path = without_bc(ele)
  human_path = len(path)-1
  source, target = path[0], path[-1]
  a, b = article_dict[source], article_dict[target]
  a, b = int(a[1:])-1, int(b[1:])-1
  shortest_path = arr[a,b]
  if shortest_path == 0:
    continue
  ratio = human_path/shortest_path
  source, target = d[source], d[target]
  cat_pairs = [(category_dict[x], category_dict[y]) for x in source for y in target]
  for pair in cat_pairs:
    ratio_sum.setdefault(pair, ratio)
    ratio_sum[pair]+= ratio
    ratio_count.setdefault(pair, 0)
    ratio_count[pair]+= 1
	
with open("category-ratios.csv", 'w') as f:
  f.write(f"From_Category, To_Category, Ratio_of_human_to_shortest\n")
  for key in sorted(ratio_sum.keys()):
    f.write(f"{key[0]}, {key[1]}, {ratio_sum[key]/ratio_count[key]}\n")