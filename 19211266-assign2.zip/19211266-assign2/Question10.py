import pandas as pd
import networkx as nx
import numpy as np

d= {}
with open("wikispeedia_paths-and-graph/categories.tsv") as f:
  for line in f:
    if "subject." in line:
      s1, s2 = line.strip().split()
      s2 = s2.split('.')
      for i in range(len(s2)):
        d.setdefault(s1, set())
        d[s1] = d[s1].union([".".join(s2[:i+1])])
d['Directdebit'] = {'subject'}
d['Donation'] = {'subject'}
d['Friend_Directdebit'] = {'subject'}
d['Pikachu'] = {'subject'}
d['Sponsorship_Directdebit'] = {'subject'}
d['Wowpurchase'] = {'subject'}
unmapped = ['Adolph_Hitler','Black_ops_2','Bogota','C++','Charlottes_web','Christmas','English','Fats','Georgia','Great','Kashmir','Long_peper','Macedonia','Mustard','Netbook','Podcast','Rat','Rss','Sportacus','Test','The','The_Rock','Usa','Western_Australia','_Zebra']
for i in unmapped:
  d[i] = {'subject'}


category_id_map = pd.read_csv("category-ids.csv")
category_dict = category_id_map.set_index("Category_Name")
category_dict = category_dict.to_dict()['Category_ID']
category_list = category_id_map.Category_ID.to_list()
finished_pairs = {(x,y):0 for x in category_list for y in category_list}
unfinished_pairs = {(x,y):0 for x in category_list for y in category_list}

########################Finished Paths################################

finished_paths = []
with open('wikispeedia_paths-and-graph/paths_finished.tsv') as f:
  for line in f:
    if line[0] in '0123456789N':
      line = line.strip().split()[3]
      finished_paths.append(line)

del finished_paths[2395]
del finished_paths[5857]
del finished_paths[9589]
del finished_paths[9872]
del finished_paths[20919]
del finished_paths[23347]
del finished_paths[24326]
del finished_paths[30761]
del finished_paths[33832]
del finished_paths[34302]
del finished_paths[38927]
del finished_paths[50466]

	  
for cat in finished_paths:
  cat = cat.split(";")
  source, desti = cat[0], cat[-1]
  source, desti = d[source], d[desti]
  cart_prod = [(category_dict[x], category_dict[y]) for x in source for y in desti]
  for ele in cart_prod:
    finished_pairs[ele]+=1
	
#########################Unfinished Paths###################################

unfinished_paths =[]
with open('wikispeedia_paths-and-graph/paths_unfinished.tsv') as f:
  for line in f:
    if line[0] in '0123456789N':
      a = line.strip().split()[3]
      a = a.split(";")[0]
      b = line.strip().split()[4]
      unfinished_paths.append((a,b))
	  

for ele in unfinished_paths:
  try:
    source, desti = d[ele[0]], d[ele[1]]
  except:
    continue
  cart_prod = [(category_dict[x], category_dict[y]) for x in source for y in desti]
  for pair in cart_prod:
    unfinished_pairs[pair]+=1
	
with open("category-pairs.csv", 'w') as f:
  f.write(f"From_Category,To_Category,Percentage_of_finished_paths,Percentage_of_unfinished_paths\n")
  for ele in finished_pairs.keys():
    if (finished_pairs[ele]+unfinished_pairs[ele])!=0:
      fp = finished_pairs[ele]/(finished_pairs[ele]+unfinished_pairs[ele])*100
      up = unfinished_pairs[ele]/(finished_pairs[ele]+unfinished_pairs[ele])*100
    else:
      fp = 0
      up = 0
    f.write(f"{ele[0]},{ele[1]},{fp},{up}\n")
