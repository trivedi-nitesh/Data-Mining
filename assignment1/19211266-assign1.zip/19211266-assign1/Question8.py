import pandas as pd


## Read neccessary files

zscore_W = pd.read_csv("zscore-week.csv")
zscore_M = pd.read_csv("zscore-month.csv")
zscore_Y = pd.read_csv("zscore-overall.csv")

################ WEEKLY COMPUTATION #################################

list1 = ['district'+ str(j) for i in range(20) for j in range(1,6)]

## top 5 weekly hotspot where method is neighborhood
top_hot_neighborW = zscore_W[["districtid", "timeid", "neighborhoodzscore"]]
top_hot_neighborW = top_hot_neighborW.sort_values(by = 'neighborhoodzscore', ascending= False).groupby("timeid").head(5).sort_values(by = 'timeid')
top_hot_neighborW['columns_names'] = list1
top_hot_neighborW = top_hot_neighborW.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_hot_neighborW['method'] = 'neighborhood'
top_hot_neighborW['spot'] = 'Hot'

## top 5 weekly coldspot where method is neighborhood
top_cold_neighborW = zscore_W[["districtid", "timeid", "neighborhoodzscore"]]
top_cold_neighborW = top_cold_neighborW.sort_values(by = 'neighborhoodzscore', ascending= True).groupby("timeid").head(5).sort_values(by = 'timeid')
top_cold_neighborW['columns_names'] = list1
top_cold_neighborW = top_cold_neighborW.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_cold_neighborW['method'] = 'neighborhood'
top_cold_neighborW['spot'] = 'Cold'

## top 5 weekly hotspot where method is state
top_hot_stateW = zscore_W[["districtid", "timeid", "statezscore"]]
top_hot_stateW = top_hot_stateW.sort_values(by = 'statezscore', ascending= False).groupby("timeid").head(5).sort_values(by = 'timeid')
top_hot_stateW['columns_names'] = list1
top_hot_stateW = top_hot_stateW.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_hot_stateW['method'] = 'state'
top_hot_stateW['spot'] = 'Hot'

## top 5 weekly coldspot where method is state
top_cold_stateW = zscore_W[["districtid", "timeid", "statezscore"]]
top_cold_stateW = top_cold_stateW.sort_values(by = 'statezscore', ascending= True).groupby("timeid").head(5).sort_values(by = 'timeid')
top_cold_stateW['columns_names'] = list1
top_cold_stateW = top_cold_stateW.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_cold_stateW['method'] = 'state'
top_cold_stateW['spot'] = 'Cold'

### Formating for desired output

top_hot_neighborW = top_hot_neighborW.reset_index()
top_hot_stateW = top_hot_stateW.reset_index()
top_cold_neighborW = top_cold_neighborW.reset_index()
top_cold_stateW = top_cold_stateW.reset_index()

weekly_5 = pd.concat([top_hot_neighborW, top_cold_neighborW, top_hot_stateW, top_cold_stateW], ignore_index= True)

#### writing computed dataframe to csv

weekly_5.to_csv("top-week.csv", index= False)


################ MONTHLY COMPUTATION #################################

list2 = ['district'+ str(j) for i in range(6) for j in range(1,6)]

## top 5 monthly hotspot where method is neighborhood
top_hot_neighborM = zscore_M[["districtid", "timeid", "neighborhoodzscore"]]
top_hot_neighborM = top_hot_neighborM.sort_values(by = 'neighborhoodzscore', ascending= False).groupby("timeid").head(5).sort_values(by = 'timeid')
top_hot_neighborM['columns_names'] = list2
top_hot_neighborM = top_hot_neighborM.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_hot_neighborM['method'] = 'neighborhood'
top_hot_neighborM['spot'] = 'Hot'

## top 5 monthly coldspot where method is neighborhood
top_cold_neighborM = zscore_M[["districtid", "timeid", "neighborhoodzscore"]]
top_cold_neighborM = top_cold_neighborM.sort_values(by = 'neighborhoodzscore', ascending= True).groupby("timeid").head(5).sort_values(by = 'timeid')
top_cold_neighborM['columns_names'] = list2
top_cold_neighborM = top_cold_neighborM.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_cold_neighborM['method'] = 'neighborhood'
top_cold_neighborM['spot'] = 'cold'

## top 5 monthly hotspot where method is state
top_hot_stateM = zscore_M[["districtid", "timeid", "statezscore"]]
top_hot_stateM = top_hot_stateM.sort_values(by = 'statezscore', ascending= False).groupby("timeid").head(5).sort_values(by = 'timeid')
top_hot_stateM['columns_names'] = list2
top_hot_stateM = top_hot_stateM.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_hot_stateM['method'] = 'state'
top_hot_stateM['spot'] = 'Hot'

## top 5 monthly coldspot where method is state
top_cold_stateM = zscore_M[["districtid", "timeid", "statezscore"]]
top_cold_stateM = top_cold_stateM.sort_values(by = 'statezscore', ascending= True).groupby("timeid").head(5).sort_values(by = 'timeid')
top_cold_stateM['columns_names'] = list2
top_cold_stateM = top_cold_stateM.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_cold_stateM['method'] = 'state'
top_cold_stateM['spot'] = 'Cold'



### Formating for desired output

top_hot_neighborM = top_hot_neighborM.reset_index()
top_hot_stateM = top_hot_stateM.reset_index()
top_cold_neighborM = top_cold_neighborM.reset_index()
top_cold_stateM = top_cold_stateM.reset_index()

monthly_5 = pd.concat([top_hot_neighborM, top_cold_neighborM, top_hot_stateM, top_cold_stateM], ignore_index= True)

#### writing computed dataframe to csv

monthly_5.to_csv("top-month.csv", index= False)



################ OVERALL COMPUTATION #################################


## Overall hot spot where method is neighborhood ##
top_hot_neighborY = zscore_Y[["districtid", "timeid", "neighborhoodzscore"]]
top_hot_neighborY = top_hot_neighborY.sort_values(by = 'neighborhoodzscore', ascending= False).groupby("timeid").head(5).sort_values(by = 'timeid')
top_hot_neighborY['columns_names'] = ['district'+ str(i) for i in range(1,6)]
top_hot_neighborY = top_hot_neighborY.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_hot_neighborY['method'] = 'neighborhood'
top_hot_neighborY['spot'] = 'Hot'


## Overall cold spot where method is neighborhood ##
top_cold_neighborY = zscore_Y[["districtid", "timeid", "neighborhoodzscore"]]
top_cold_neighborY = top_cold_neighborY.sort_values(by = 'neighborhoodzscore', ascending= True).groupby("timeid").head(5).sort_values(by = 'timeid')
top_cold_neighborY['columns_names'] = ['district'+ str(i) for i in range(1,6)]
top_cold_neighborY = top_cold_neighborY.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_cold_neighborY['method'] = 'neighborhood'
top_cold_neighborY['spot'] = 'Cold'


## Overall hot spot where method is state ##
top_hot_stateY = zscore_Y[["districtid", "timeid", "statezscore"]]
top_hot_stateY = top_hot_stateY.sort_values(by = 'statezscore', ascending= False).groupby("timeid").head(5).sort_values(by = 'timeid')
top_hot_stateY['columns_names'] = ['district'+ str(i) for i in range(1,6)]
top_hot_stateY = top_hot_stateY.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_hot_stateY['method'] = 'state'
top_hot_stateY['spot'] = 'Hot'


## Overall cold spot where method is state ##
top_cold_stateY = zscore_Y[["districtid", "timeid", "statezscore"]]
top_cold_stateY = top_cold_stateY.sort_values(by = 'statezscore', ascending= True).groupby("timeid").head(5).sort_values(by = 'timeid')
top_cold_stateY['columns_names'] = ['district'+ str(i) for i in range(1,6)]
top_cold_stateY = top_cold_stateY.pivot(index= 'timeid', columns= 'columns_names'  , values= 'districtid')
top_cold_stateY['method'] = 'state'
top_cold_stateY['spot'] = 'Cold'

### Formating for desired output

top_hot_neighborY = top_hot_neighborY.reset_index()
top_hot_stateY = top_hot_stateY.reset_index()
top_cold_neighborY = top_cold_neighborY.reset_index()
top_cold_stateY = top_cold_stateY.reset_index()

year_5 = pd.concat([top_hot_neighborY, top_cold_neighborY, top_hot_stateY, top_cold_stateY], ignore_index= True)


#### writing computed dataframe to csv

year_5.to_csv("top-overall.csv", index= False)










































































































