## import pandas
import pandas as pd

## Read required files for processing

district_df = pd.read_csv("district_df.csv")
df_dates = pd.read_csv("df_dates.csv")
dfW = pd.read_csv("cases-week.csv")
dfM = pd.read_csv("cases-month.csv")
dfY = pd.read_csv("cases-overall.csv")

## Function to extract neighbors mean and stdev weekly, monthly and overall

def neighbor_MS(dist_id, neighbor_ids, df_WMO):
  neighbor_cases = df_WMO[df_WMO.districtid.isin(neighbor_ids)]
  mean = pd.DataFrame()
  mean["neighbormean"] = df_WMO[df_WMO.districtid.isin(neighbor_ids)].groupby("timeid").mean()["cases"]
  mean["neighborstdev"] = df_WMO[df_WMO.districtid.isin(neighbor_ids)].groupby("timeid").std()["cases"]
  mean = mean.round(2)
  mean["districtid"] = dist_id
  mean = mean.reset_index()
  mean = mean[["districtid", "timeid", "neighbormean", "neighborstdev"]]
  return mean


#### Weekly computation

week = {}
for dist_id in range(101,723):
  neighbor_ids = district_df[district_df.from_id == dist_id]["to_id"].to_list()
  week[dist_id] = neighbor_MS(dist_id, neighbor_ids, dfW)

dfW_N = pd.concat(week.values(), ignore_index= True)


## monthly computation ##

month = {}
for dist_id in range(101,723):
  neighbor_ids = district_df[district_df.from_id == dist_id]["to_id"].to_list()
  month[dist_id] = neighbor_MS(dist_id, neighbor_ids, dfM)

dfM_N = pd.concat(month.values(), ignore_index= True)

## Overall computation ##

year = {}
for dist_id in range(101,723):
  neighbor_ids = district_df[district_df.from_id == dist_id]["to_id"].to_list()
  year[dist_id] = neighbor_MS(dist_id, neighbor_ids, dfY)

dfY_N = pd.concat(year.values(), ignore_index= True)

#### writing all files to csv

dfW_N.to_csv("neighbor-week.csv", index= False)
dfM_N.to_csv("neighbor-month.csv", index= False)
dfY_N.to_csv("neighbor-overall.csv", index= False)























