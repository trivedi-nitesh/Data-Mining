###### assign1 FOLDER CONTENTS #########

Folder contains eight python files named as Question1, Question2, ... Question8.
It has two more files named neighbor-district.json and data.json, where first was part of assignment package
while the other one has been extracted from covid19.org API's.
Folder also contains the pdf of report along with report.tex.

################# REQUIREMENTS #############################

Below is the list of packages(along with their versions) used in code.
################################################################################
Packages	  Versions

fuzzywuzzy         0.18.0
pandas             1.1.2
numpy              1.19.2

#################################################################################

########## HOW TO EXECUTE CODE ##################################################
 
Shell executable files exist in folder named assign1. All shell files have names as of stated in assignment itself,
except Question1 shell file has name Q1.sh. Question1 file has been named differently since no name was given for
this file in assignment.

###### Order(top to bottom) to be followed while exectuing shell files independently ###################

1) Q1.sh
2) case-generator.sh
3) edge-generator.sh
4) neighbor-generator.sh
5) state-generator.sh
6) zscore-generator.sh
7) method-spot-generator.sh
8) top-generator.sh

############### SINGLE SHELL SCRIPT TO EXECUTE COMPLETE ASSIGNMENT ######################

In order to execute complete assignment as a whole, please execute "assign1.sh". This will generate outputs
of all questions at a time.


NOTE- Once Q1.sh is executed it generates two csv files along with required "district-neighbor-modified.json".
The two generated csv named "district_df.csv" and "df_dates.csv" are not part of any required output. They
have been generated so that further computation can be done efficiently.