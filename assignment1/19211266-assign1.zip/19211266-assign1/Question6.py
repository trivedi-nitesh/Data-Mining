import pandas as pd
import numpy as np
## Read neccessary files

dfW = pd.read_csv("cases-week.csv")
dfM = pd.read_csv("cases-month.csv")
dfY = pd.read_csv("cases-overall.csv")
dfW_N = pd.read_csv("neighbor-week.csv")
dfM_N = pd.read_csv("neighbor-month.csv")
dfY_N = pd.read_csv("neighbor-overall.csv")
dfW_S = pd.read_csv("state-week.csv")
dfM_S = pd.read_csv("state-month.csv")
dfY_S = pd.read_csv("state-overall.csv")


## Function to calculate zscore weekly, monthly and overall

def zscore_WMO(dfWMO, dfWMO_N, dfWMO_S):
  merged_df = dfWMO.merge(dfWMO_N, how='inner', 
          left_on=["districtid", "timeid"], 
          right_on=["districtid","timeid"])
  merged_df = merged_df.merge(dfWMO_S, how= 'inner',
                            left_on=["districtid", "timeid"],
                            right_on=["districtid","timeid"])
  merged_df["neighborhoodzscore"] = (merged_df.cases-merged_df.neighbormean)/merged_df.neighborstdev
  merged_df["statezscore"] = (merged_df.cases-merged_df.statemean)/merged_df.statestdev
  merged_df = merged_df.drop(columns= ["cases", "neighbormean", "neighborstdev", "statemean", "statestdev"])
  merged_df = merged_df.round(2)
  merged_df = merged_df.replace([np.inf, -np.inf], np.nan).dropna(subset=["neighborhoodzscore", "statezscore"], how="all")
  return merged_df



## computing zscore by calling function

zscore_W = zscore_WMO(dfW, dfW_N, dfW_S)
zscore_M = zscore_WMO(dfM, dfM_N, dfM_S)
zscore_Y = zscore_WMO(dfY, dfY_N, dfY_S)

## writing computed dataframes to csv files

zscore_W.to_csv("zscore-week.csv", index= False)
zscore_M.to_csv("zscore-month.csv", index= False)
zscore_Y.to_csv("zscore-overall.csv", index= False)


























