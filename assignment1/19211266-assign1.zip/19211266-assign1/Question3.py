import pandas as pd

district_df = pd.read_csv("district_df.csv")

## Creating edge-graph from assigned ids(101 onwards..)
district_df[["from_id", "to_id"]].to_csv("edge-graph.csv", index= False)
