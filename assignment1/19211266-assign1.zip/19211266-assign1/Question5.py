## import pandas and numpy

import pandas as pd
import numpy as np

## Read neccessary files

df_dates = pd.read_csv("df_dates.csv")
dfW = pd.read_csv("cases-week.csv")
dfM = pd.read_csv("cases-month.csv")
dfY = pd.read_csv("cases-overall.csv")

## Function to calculate mean and stdev

def state_WMO(df_WMO, dist_id, state_districts):
  mean = pd.DataFrame()
  if len(state_districts) < 1 :
    mean = mean.append({"districtid" : dist_id, "timeid" : 0, "statemean" : 0, "statestdev" : 0}, ignore_index= True)
    mean.timeid = mean.timeid.astype(int)
  else:
    grouped_temp_df = df_WMO[df_WMO.districtid.isin(state_districts)].groupby("timeid")
    mean["statemean"] = grouped_temp_df.mean()["cases"]
    mean["statestdev"] = grouped_temp_df.std()["cases"]
    mean["statemean"] = grouped_temp_df["cases"].apply(np.mean)
    mean["statestdev"] = grouped_temp_df["cases"].apply(np.std)
  mean = mean.round(2)
  mean["districtid"] = dist_id
  mean = mean.reset_index()
  mean = mean[["districtid", "timeid", "statemean", "statestdev"]]
  return mean

## weekly computation

week = {}
for dist_id in range(101, 723):
  state = df_dates[df_dates["district_id"]== dist_id]["state"].unique()[0]
  state_districts = list(df_dates[df_dates["state"]== state]["district_id"].unique())
  state_districts.remove(dist_id)
  week[dist_id] = state_WMO(dfW, dist_id, state_districts)
  
dfW_S = pd.concat(week.values(), ignore_index= True)

## monthly computation

month = {}
for dist_id in range(101, 723):
  state = df_dates[df_dates["district_id"]== dist_id]["state"].unique()[0]
  state_districts = list(df_dates[df_dates["state"]== state]["district_id"].unique())
  state_districts.remove(dist_id)
  month[dist_id] = state_WMO(dfM, dist_id, state_districts)

dfM_S = pd.concat(month.values(), ignore_index= True)


## overall computation

year = {}
for dist_id in range(101, 723):
  state = df_dates[df_dates["district_id"]== dist_id]["state"].unique()[0]
  state_districts = list(df_dates[df_dates["state"]== state]["district_id"].unique())
  state_districts.remove(dist_id)
  year[dist_id] = state_WMO(dfY, dist_id, state_districts)

dfY_S = pd.concat(year.values(), ignore_index= True)

### writing dataframes to files

dfW_S.to_csv("state-week.csv", index= False)
dfM_S.to_csv("state-month.csv", index= False)
dfY_S.to_csv("state-overall.csv", index= False)






























