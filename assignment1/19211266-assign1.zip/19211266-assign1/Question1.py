## importing modules

import json
import pandas as pd
from fuzzywuzzy import fuzz, process
import time
from datetime import datetime
import warnings


warnings.filterwarnings("ignore")


## Load Data ###
with open("neighbor-districts.json", "rt") as f:
  district_data= json.load(f)
district_tuples= [(a, b) for a in district_data.keys() for b in district_data[a]]

district_df= pd.DataFrame(district_tuples, columns= ["from", "to"])

district_df["dist_from_id"] = district_df["from"].str.split("/")
district_df[["from", "dist_from_id"]] = pd.DataFrame(district_df["dist_from_id"].values.tolist(), 
                                                     index=district_df.index)
district_df["dist_to_id"] = district_df["to"].str.split("/")
district_df[["to", "dist_to_id"]] = pd.DataFrame(district_df["dist_to_id"].values.tolist(), 
                                                     index=district_df.index)
def toLower(string):
  string = string.split("_district")[0]
  return string.lower().replace("_", " ")
district_df["from"] = district_df["from"].apply(toLower)
district_df["to"] = district_df["to"].apply(toLower)

###### Handling Districts with same name in more than one state #####
##### Aurangabad of Bihar ##########
district_df.loc[district_df['dist_from_id'] == "Q43086", 'from'] = "aurangabad_BR"
district_df.loc[district_df['dist_to_id'] == "Q43086", 'to'] = "aurangabad_BR"
##### Aurangabad of Maharastra ##########
district_df.loc[district_df['dist_from_id'] == "Q592942", 'from'] = "aurangabad_MH"
district_df.loc[district_df['dist_to_id'] == "Q592942", 'to'] = "aurangabad_MH"
##### Balrampur of Jharkhand ##########
district_df.loc[district_df['dist_from_id'] == "Q16056268", 'from'] = "balrampur_CT"
district_df.loc[district_df['dist_to_id'] == "Q16056268", 'to'] = "balrampur_CT"
##### Balrampur of UP ##########
district_df.loc[district_df['dist_from_id'] == "Q1948380", 'from'] = "balrampur_UP"
district_df.loc[district_df['dist_to_id'] == "Q1948380", 'to'] = "balrampur_UP"
##### Bilaspur of Jharkhand ##########
district_df.loc[district_df['dist_from_id'] == "Q100157", 'from'] = "bilaspur_CT"
district_df.loc[district_df['dist_to_id'] == "Q100157", 'to'] = "bilaspur_CT"
##### Bilaspur of HP ##########
district_df.loc[district_df['dist_from_id'] == "Q1478939", 'from'] = "bilaspur_HP"
district_df.loc[district_df['dist_to_id'] == "Q1478939", 'to'] = "bilaspur_HP"
##### Hamirpur of HP ##########
district_df.loc[district_df['dist_from_id'] == "Q2086180", 'from'] = "hamirpur_HP"
district_df.loc[district_df['dist_to_id'] == "Q2086180", 'to'] = "hamirpur_HP"
##### Hamirpur of UP ##########
district_df.loc[district_df['dist_from_id'] == "Q2019757", 'from'] = "hamirpur_UP"
district_df.loc[district_df['dist_to_id'] == "Q2019757", 'to'] = "hamirpur_UP"
##### Pratapgarh of UP ##########
district_df.loc[district_df['dist_from_id'] == "Q1473962", 'from'] = "pratapgarh_UP"
district_df.loc[district_df['dist_to_id'] == "Q1473962", 'to'] = "pratapgarh_UP"
##### Pratapgarh of RJ ##########
district_df.loc[district_df['dist_from_id'] == "Q1585433", 'from'] = "pratapgarh_RJ"
district_df.loc[district_df['dist_to_id'] == "Q1585433", 'to'] = "pratapgarh_RJ"

### Handling vijaypura seperately
district_df.loc[district_df['dist_from_id'] == "Q1727570", 'from'] = "vijayapura"
district_df.loc[district_df['dist_to_id'] == "Q1727570", 'to'] = "vijayapura"
# Appending data.json to dataframe and preprocessing
file_path = r"data.json"
with open(file_path, "rt") as f:
    data_dict = json.load(f)
## Extracting structure of data.json to create a dataframe
list_of_tups_data = []
for date in data_dict.keys(): # data_dict.keys(), test_dates
    for state in data_dict[date]:
        state_dict = data_dict[date][state]
        
        state_delta = state_dict.get("delta", 0)
        if isinstance(state_delta, dict):
            state_delta = state_delta.get("confirmed", 0)
        
        districts_dict = state_dict.get("districts", "NOT EXISTS")
        # print(districts_dict)
        if isinstance(districts_dict, dict):
            for district in districts_dict:
                try:
                    district_delta = districts_dict[district]["delta"]["confirmed"]
                except KeyError:
                    district_delta = 0
                tup = (date, state, state_delta, district, district_delta)
                list_of_tups_data.append(tup)
        else:
            tup = (date, state, state_delta, districts_dict, 0)
            list_of_tups_data.append(tup)

df = pd.DataFrame(list_of_tups_data, 
                  columns=["date", "state", "state_delta", "district", "district_delta"])
df["district"] = df["district"].apply(toLower)

## Updating covid df distrcits names therefore to match names correctly

#### AURANGABAD ####
df.loc[(df['state'] == "BR") & (df['district'] == "aurangabad"), 'district'] = "aurangabad_BR"
df.loc[(df['state'] == "MH") & (df['district'] == "aurangabad"), 'district'] = "aurangabad_MH"
#### balrampur ####
df.loc[(df['state'] == "CT") & (df['district'] == "balrampur"), 'district'] = "balrampur_CT"
df.loc[(df['state'] == "UP") & (df['district'] == "balrampur"), 'district'] = "balrampur_UP"
#### bilaspur ####
df.loc[(df['state'] == "CT") & (df['district'] == "bilaspur"), 'district'] = "bilaspur_CT"
df.loc[(df['state'] == "HP") & (df['district'] == "bilaspur"), 'district'] = "bilaspur_HP"
#### HAMIRPUR ####
df.loc[(df['state'] == "HP") & (df['district'] == "hamirpur"), 'district'] = "hamirpur_HP"
df.loc[(df['state'] == "UP") & (df['district'] == "hamirpur"), 'district'] = "hamirpur_UP"
#### PRATAPGARH ####
df.loc[(df['state'] == "UP") & (df['district'] == "pratapgarh"), 'district'] = "pratapgarh_UP"
df.loc[(df['state'] == "RJ") & (df['district'] == "pratapgarh"), 'district'] = "pratapgarh_RJ"

## Function to extract neighbor districts and compute difference from covid districts

def compute_diff(df, district_df, typ):
  districts_nfile = pd.Series(district_df['from'].values, index= None).unique().tolist()
  districts_cfile = pd.Series(df['district'].values, index= None).unique().tolist()
  districts_cfile= set(districts_cfile)
  districts_nfile = set(districts_nfile)
  if typ == "neighbor":
    districts_matchN = districts_nfile.difference(districts_cfile)
  if typ == "covid":
    districts_matchN = districts_cfile.difference(districts_nfile)
  districts_matchN = list(districts_matchN)
  districts_matchN.sort()
  return [districts_matchN, districts_nfile, districts_cfile]

## finding scores for not matching strings ### Function to find fuzz.ratio

def fuzz_score(districts_matchN, districts_file, threshold):
  score_R= {}
  for dis in districts_matchN:
    score_R[dis]=process.extract(dis, districts_file, scorer=fuzz.ratio)
  dictionary = {}
  for k, v in score_R.items():
    first_value = v[0]
    name, score = first_value
    if score >= threshold:
        dictionary[k] = name
  return dictionary

### calling fuzz.ratio function on A-B with B-A where A= 'districts in neighbor.json' and B= 'districts in data.json'

list_1 = compute_diff(df, district_df, typ= "neighbor")
districts_matchN = list_1[0]
list_1 = compute_diff(df, district_df, typ= "covid")
districts_matchC = list_1[0]

mapper = fuzz_score(districts_matchN, districts_matchC, 80)

### Mapping selected districts( where fuzz score is above 80) names to neighbor file

district_df['from'] = district_df['from'].replace(mapper)
district_df['to'] = district_df['to'].replace(mapper)

## mapping other district names like delhi and mumbai to district_df

# extract id and district

id_df = district_df[["from", "dist_from_id"]]
id_df = id_df.rename(columns={"dist_from_id":"id", "from":"district"})
id_df = id_df[["id", "district"]]
id_df = id_df.drop_duplicates(subset=["id", "district"], keep="first", ignore_index=True)

### Replacing delhi, mumbai and other districts with ids and dropping duplicates

df2 = id_df[id_df.district.str.contains("delhi", case=False)]
dist_id_mappings = {}
district_name_mappings = {}
dist_id_mappings = {dist_id:"Q107941" for dist_id in df2.id.values.tolist()[1:]}
dist_id_mappings["Q83486"] = "Q107941"  # for shahdara
dist_id_mappings["Q2085374"] = "Q2341660"  #mumbai suburban

district_name_mappings = {val:"delhi" for val in df2.district.values.tolist()}
district_name_mappings["shahdara"] = "delhi"
district_name_mappings["mumbai city"] = "mumbai"
district_name_mappings["mumbai suburban"] = "mumbai"
district_name_mappings["purba champaran"] = "east champaran"
district_name_mappings["pashchim champaran"] = "west champaran"
district_name_mappings["purbi singhbhum"] = "east singhbhum"
district_name_mappings["pashchimi singhbhum"] = "west singhbhum"
district_name_mappings["kaimur (bhabua)"] = "kaimur"
district_name_mappings["sahibzada ajit singh nagar"] = "s.a.s. nagar"
district_name_mappings["ysr"] = "y.s.r. kadapa"
district_name_mappings["the dangs"] = "dang"
district_name_mappings["bellary"] = "ballari"
district_name_mappings["dantewada"] = "dakshin bastar dantewada"
district_name_mappings["muktsar"] = "sri muktsar sahib"
district_name_mappings["jyotiba phule nagar"] = "amroha"
district_name_mappings["faizabad"] = "ayodhya"
district_name_mappings["baleshwar"] = "balasore"
district_name_mappings["bid"] = "beed"
district_name_mappings["belgaum"] = "belagavi"
district_name_mappings["sant ravidas nagar"] = "bhadohi"
district_name_mappings["hugli"] = "hooghly"
district_name_mappings["sri potti sriramulu nellore"] = "s.p.s. nellore"
district_name_mappings["lakhimpur"] = "lakhimpur kheri"
district_name_mappings["tirunelveli kattabo"] = "tirunelveli"
district_name_mappings["kochbihar"] = "cooch behar"
district_name_mappings["palghat"] = "palakkad"
district_name_mappings["sonapur"] = "subarnapur"

district_df["dist_from_id"] = district_df["dist_from_id"].replace(dist_id_mappings)
district_df["dist_to_id"] = district_df["dist_to_id"].replace(dist_id_mappings)
district_df["from"] = district_df["from"].replace(district_name_mappings)
district_df["to"] = district_df["to"].replace(district_name_mappings)

district_df = district_df.drop_duplicates(keep='first')
district_df = district_df[district_df["from"] != district_df["to"]]

list_1 = compute_diff(df, district_df, typ= "neighbor")
districts_matchN = list_1[0]

district_df = district_df[~district_df["from"].isin(districts_matchN)]
district_df = district_df[~district_df["to"].isin(districts_matchN)]

## mapping ids(101 onwards) to neighbor file districts dataframe

sorted_district= sorted(district_df["from"].unique().tolist())
district_ids= {location: ids for ids, location in enumerate(sorted_district, 101)}

district_df['from_id']= district_df['from'].map(district_ids)
district_df['to_id']= district_df['to'].map(district_ids)

#### Generating modified-neighbor.json

district_df["from/id"] = district_df['from'] + '/' + district_df['dist_from_id']
district_df["to/id"] = district_df['to'] + '/' + district_df['dist_to_id']
district_df2 = district_df[["from/id", "to/id"]]

dist_dict = {}
for from_dist in district_df2["from/id"].unique():
    dist_dict[from_dist] = district_df2[district_df2["from/id"] == from_dist]["to/id"].to_list()

data = json.dumps(dist_dict, indent=2, sort_keys=True)
with open("neighbor-districts-modified.json", "w") as f:
    f.write(data)    

#### Adding adding ids(101 onwards) in covid df

df['district_id'] = df['district'].replace(district_ids)

### Removing districts names of covid portal which do not match any of the names in neighbor.json file

list_1 = compute_diff(df, district_df, typ= "covid")
districts_matchC = list_1[0]
df_dates = df[~df["district"].isin(districts_matchC)]

## extracting covid data between required dates in a seprate dataframe

d1 = datetime(2020,3,15)
d2 = datetime(2020,9,5)
df_dates['date'] = pd.to_datetime(df_dates['date'])
df_dates = df_dates[(df_dates.date >= d1) & (df_dates.date <= d2)]

#### writing pre-processed dataframes( district_df and df_dates respect..) since they are required in further questions

district_df.to_csv("district_df.csv", index= False)
df_dates.to_csv("df_dates.csv", index= False)
































