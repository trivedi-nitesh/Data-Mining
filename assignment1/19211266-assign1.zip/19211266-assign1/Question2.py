## importing modules
import pandas as pd
from datetime import datetime
from datetime import date
#### Reading district_df and df_dates

district_df = pd.read_csv("district_df.csv")
df_dates = pd.read_csv("df_dates.csv")
df_dates['date'] = pd.to_datetime(df_dates['date'])
### Function to extract weekly, monthly and overall cases

def cases_WMO(df_dates, dist, wmo):
  t_df = df_dates[df_dates['district'] == dist]
  #t_df = t_df[(t_df.date >= d1) & (t_df.date <= d2)]
  t_df = t_df[["date", "district_id", "district_delta"]]
  t_df.set_index("date", inplace= True)
  dist_id = t_df.iloc[0]["district_id"]
  x = t_df.resample(wmo).agg({"district_delta":"sum"})
  x = x.reset_index()
  x["dist_id"] =  dist_id
  x["time_id"] = range(1, len(x.index)+1)
  col= ["dist_id", "time_id", "district_delta"]
  x = x[col]
  x = x.rename(columns= {"dist_id": "districtid", "time_id": "timeid", "district_delta": "cases"})
  return x


## computing weekly cases

week ={}
for dist in df_dates.district.unique():
  week[dist] = cases_WMO(df_dates, dist, "W")

dfW = pd.concat(week.values(), ignore_index= True)
dfW.sort_values(by= ["districtid","timeid"], inplace= True)

#### computing monthly cases

month ={}
for dist in df_dates.district.unique():
  month[dist] = cases_WMO(df_dates, dist, "M")

dfM = pd.concat(month.values(), ignore_index= True)
dfM.sort_values(by= ["districtid","timeid"], inplace= True)


### computing overall cases

year ={}
for dist in df_dates.district.unique():
  year[dist] = cases_WMO(df_dates, dist, "Y")

dfY = pd.concat(year.values(), ignore_index= True)
dfY.sort_values(by= ["districtid","timeid"], inplace= True)

### writing all computed dataframes to respective files

dfW.to_csv("cases-week.csv", index= False)
dfM.to_csv("cases-month.csv", index= False)
dfY.to_csv("cases-overall.csv", index= False)




























