import pandas as pd


## Read neccessary files

dfW = pd.read_csv("cases-week.csv")
dfM = pd.read_csv("cases-month.csv")
dfY = pd.read_csv("cases-overall.csv")
dfW_N = pd.read_csv("neighbor-week.csv")
dfM_N = pd.read_csv("neighbor-month.csv")
dfY_N = pd.read_csv("neighbor-overall.csv")
dfW_S = pd.read_csv("state-week.csv")
dfM_S = pd.read_csv("state-month.csv")
dfY_S = pd.read_csv("state-overall.csv")

## Function to compute hotspots where method is neighborhood

def spot_detection_neighbor(dfWMO, dfWMO_N):
  merged_df = dfWMO.merge(dfWMO_N, how = 'inner',
                          left_on = ["districtid", "timeid"],
                          right_on = ["districtid", "timeid"])
  merged_df["spot"] = merged_df.cases > (merged_df.neighbormean + merged_df.neighborstdev)
  merged_df["spot"] = merged_df.spot.astype(str)
  merged_df["spot"] = merged_df.spot.map({'False': 'Cold', 'True': 'Hot'})
  merged_df["method"] = "neighborhood"
  merged_df = merged_df[["timeid", "method", "spot", "districtid"]]
  return merged_df


## Function to compute hotspots where method is state

def spot_detection_state(dfWMO, dfWMO_S):
  merged_df = dfWMO.merge(dfWMO_S, how = 'inner',
                          left_on = ["districtid", "timeid"],
                          right_on = ["districtid", "timeid"])
  merged_df["spot"] = merged_df.cases > (merged_df.statemean + merged_df.statestdev)
  merged_df["spot"] = merged_df.spot.astype(str)
  merged_df["spot"] = merged_df.spot.map({'False': 'Cold', 'True': 'Hot'})
  merged_df["method"] = "state"
  merged_df = merged_df[["timeid", "method", "spot", "districtid"]]
  return merged_df


#### weekly computation

method_spot_week = {}
method_spot_week["neighbor"] = spot_detection_neighbor(dfW, dfW_N)
method_spot_week["state"] = spot_detection_state(dfW, dfW_S)

df_msw = pd.concat(method_spot_week.values(), ignore_index= True)


#### monthly computation

method_spot_month = {}
method_spot_month["neighbor"] = spot_detection_neighbor(dfM, dfM_N)
method_spot_month["state"] = spot_detection_state(dfM, dfM_S)

df_msm = pd.concat(method_spot_month.values(), ignore_index= True)

### overall computation

method_spot_year = {}
method_spot_year["neighbor"] = spot_detection_neighbor(dfY, dfY_N)
method_spot_year["state"] = spot_detection_state(dfY, dfY_S)

df_msy = pd.concat(method_spot_year.values(), ignore_index= True)

#### writing computed dataframes to csv files

df_msw.to_csv("method-spot-week.csv", index= False)
df_msm.to_csv("method-spot-month.csv", index= False)
df_msy.to_csv("method-spot-overall.csv", index= False)

























